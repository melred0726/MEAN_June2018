import { Component, OnInit, Input, EventEmitter, Output} from '@angular/core';
import { CategoriesDaoService } from '../categories-dao.service';
import { Category } from '../Category';

@Component({
  selector: 'select-categories',
  templateUrl: './select-categories.component.html',
  styles: []
})
export class SelectCategoriesComponent implements OnInit {

  @Input()
  name: string;

  @Output()
  pickCategory = new EventEmitter<Category>();

  categories: Category[];

  constructor(private dao: CategoriesDaoService) { }

  handleChange(category: Category) {
    this.pickCategory.emit(category);
  }

  ngOnInit() {
    this.dao.list().subscribe(results => this.categories = results);
    // console.log('list: ', this.dao.list);
  }

}
