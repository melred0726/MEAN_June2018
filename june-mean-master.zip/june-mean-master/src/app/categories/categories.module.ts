import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import { CategoriesRoutingModule } from './categories-routing.module';
import { SelectCategoriesComponent } from './select-categories/select-categories.component';

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    CategoriesRoutingModule
  ],
  declarations: [SelectCategoriesComponent],
  exports: [SelectCategoriesComponent]
})
export class CategoriesModule { }
