import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Category } from './Category';

@Injectable({
  providedIn: 'root'
})
export class CategoriesDaoService {

  constructor(private client: HttpClient) { }

  list(): Observable<Category[]> {
    return this.client.get<Category[]>('http://localhost:8001/categories/');
  }
}
