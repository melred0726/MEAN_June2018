export interface Address {
    street: string;
    city: string;
    state: string;
    zip: string;
}

export interface Payee {
    payeeName: string;
    id: string;
    address: Address;
    categoryId: string | number;
    image?: string;
    motto?: string;
    version: number;
    active: boolean;
}