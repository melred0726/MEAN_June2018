import { PayeesModule } from './payees.module';

describe('PayeesModule', () => {
  let payeesModule: PayeesModule;

  beforeEach(() => {
    payeesModule = new PayeesModule();
  });

  it('should create an instance', () => {
    expect(payeesModule).toBeTruthy();
  });
});
