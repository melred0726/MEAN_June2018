import { Injectable } from '@angular/core';
import { PayeeSearchCriteria } from './payees-search/payees-search.component';
import { Payee } from './Payee';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PayeesDaoService {

  constructor(private httpClient: HttpClient) { }

  getKey(key) {
    switch (key) {
      case 'payeeName':
        return 'payeeName_like';
      case 'city':
      case 'state':
        return `address.${key}_like`;
      case 'category':
        return 'categoryId_like';
    }
  }

  betterCriteriaToParams(criteria: PayeeSearchCriteria) {
    const params = {};
    Object.keys(criteria).forEach(key => params[this.getKey(key)] = criteria[key]);
    return params;
  }

  criteriaToParams(criteria: PayeeSearchCriteria) {
    const params = {};
    Object.keys(criteria).forEach(key => {
      if (key === 'payeeName') {
        params[key + '_like'] = criteria[key];
      }

      if (key === 'city') {
        params['address.city_like'] = criteria[key];
      }

      if (key === 'state') {
        params['address.state_like'] = criteria[key];
      }

      if (key === 'category') {
        params['categoryId_like'] = criteria[key];
      }
    });
    return params;
  }

  search(criteria: PayeeSearchCriteria): Observable<Payee[]> {
    const params = this.betterCriteriaToParams(criteria);

    return this.httpClient
      .get<Payee[]>('http://localhost:8001/payees',
        { params });
  }
}
