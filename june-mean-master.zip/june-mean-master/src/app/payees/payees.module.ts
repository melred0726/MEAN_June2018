import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import {CategoriesModule} from '../categories/categories.module';

import { PayeesRoutingModule } from './payees-routing.module';
import { PayeesManagerComponent } from './payees-manager/payees-manager.component';
import { PayeesSearchComponent } from './payees-search/payees-search.component';
import { PayeesListComponent } from './payees-list/payees-list.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    CategoriesModule,
    PayeesRoutingModule
  ],
  declarations: [PayeesManagerComponent, PayeesSearchComponent, PayeesListComponent],
  exports: [PayeesManagerComponent]
})
export class PayeesModule { }
