import { TestBed, inject } from '@angular/core/testing';

import { PayeesDaoService } from './payees-dao.service';

describe('PayeesDaoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PayeesDaoService]
    });
  });

  it('should be created', inject([PayeesDaoService], (service: PayeesDaoService) => {
    expect(service).toBeTruthy();
  }));
});
