import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'better-greeter',
  templateUrl: './better-greeter.component.html',
  styleUrls: ['./better-greeter.component.css']
})
export class BetterGreeterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
