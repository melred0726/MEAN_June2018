import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BetterGreeterComponent } from './better-greeter.component';

describe('BetterGreeterComponent', () => {
  let component: BetterGreeterComponent;
  let fixture: ComponentFixture<BetterGreeterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BetterGreeterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BetterGreeterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
