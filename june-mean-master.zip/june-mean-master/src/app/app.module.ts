import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import { BetterGreeterComponent } from './better-greeter/better-greeter.component';
import { PayeesModule } from './payees/payees.module';
import { CategoriesModule } from './categories/categories.module';

@NgModule({
  declarations: [
    AppComponent,
    BetterGreeterComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    PayeesModule,
    CategoriesModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
